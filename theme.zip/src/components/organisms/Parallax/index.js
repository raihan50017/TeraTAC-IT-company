export { default } from './Parallax';
