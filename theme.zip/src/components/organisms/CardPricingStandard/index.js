export { default } from './CardPricingStandard';
