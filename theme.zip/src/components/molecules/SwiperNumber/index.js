export { default } from './SwiperNumber';
