export { default } from './TypedText';
