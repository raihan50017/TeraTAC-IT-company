export { default as SectionHeader } from './SectionHeader';
export { default as IconAlternate } from './IconAlternate';
export { default as SwiperImage } from './SwiperImage';
export { default as DescriptionCta } from './DescriptionCta';
export { default as CountUpNumber } from './CountUpNumber';
export { default as OverlapedImages } from './OverlapedImages';
export { default as SwiperNumber } from './SwiperNumber';
export { default as TypedText } from './TypedText';
