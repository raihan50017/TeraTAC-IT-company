export { default } from './CountUpNumber';
