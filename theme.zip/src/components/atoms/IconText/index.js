export { default } from './IconText';
