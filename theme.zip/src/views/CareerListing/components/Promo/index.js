export { default } from './Promo';
