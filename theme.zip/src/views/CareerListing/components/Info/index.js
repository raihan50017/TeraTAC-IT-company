export { default } from './Info';
