export { default } from './Vertical';
