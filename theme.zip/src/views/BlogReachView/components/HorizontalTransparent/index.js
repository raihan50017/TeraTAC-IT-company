export { default } from './HorizontalTransparent';
