export { default } from './VerticalTransparent';
