export { default as Hero } from './Hero';
export { default as Horizontal } from './Horizontal';
export { default as HorizontalCover } from './HorizontalCover';
export { default as HorizontalTransparent } from './HorizontalTransparent';
export { default as Vertical } from './Vertical';
export { default as VerticalOverlaped } from './VerticalOverlaped';
export { default as VerticalTransparent } from './VerticalTransparent';
