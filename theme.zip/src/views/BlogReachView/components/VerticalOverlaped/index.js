export { default } from './VerticalOverlaped';
