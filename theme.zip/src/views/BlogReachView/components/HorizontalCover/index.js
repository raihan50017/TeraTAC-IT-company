export { default } from './HorizontalCover';
