export { default as Customization } from './Customization';
export { default as Download } from './Download';
export { default as Hero } from './Hero';
export { default as Hub } from './Hub';
export { default as Partners } from './Partners';
export { default as Pricings } from './Pricings';
export { default as Reviews } from './Reviews';
export { default as Support } from './Support';
