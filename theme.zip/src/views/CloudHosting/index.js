export { default } from './CloudHosting';
