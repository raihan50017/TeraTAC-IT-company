export { default } from './HowItWorks';
