export { default } from './Pricings';
