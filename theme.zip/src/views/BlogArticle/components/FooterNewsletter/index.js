export { default } from './FooterNewsletter';
