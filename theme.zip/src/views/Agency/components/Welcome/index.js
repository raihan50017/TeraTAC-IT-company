export { default } from './Welcome';
