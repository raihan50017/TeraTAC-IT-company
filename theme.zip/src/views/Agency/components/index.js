export { default as Welcome } from './Welcome';
export { default as MadCap } from './MadCap';
export { default as Process } from './Process';
export { default as Adidas } from './Adidas';
export { default as Larq } from './Larq';
export { default as Nike } from './Nike';
export { default as Reviews } from './Reviews';
export { default as Contact } from './Contact';
