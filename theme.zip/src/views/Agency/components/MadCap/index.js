export { default } from './MadCap';
