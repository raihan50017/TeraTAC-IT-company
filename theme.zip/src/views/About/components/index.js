export { default as Contact } from './Contact';
export { default as Gallery } from './Gallery';
export { default as Hero } from './Hero';
export { default as Partners } from './Partners';
export { default as Story } from './Story';
export { default as Team } from './Team';
export { default as WhoWeAre } from './WhoWeAre';
