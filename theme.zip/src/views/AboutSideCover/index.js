export { default } from './AboutSideCover';
