export { default as Contact } from './Contact';
export { default as Locations } from './Locations';
export { default as Story } from './Story';
export { default as Team } from './Team';
