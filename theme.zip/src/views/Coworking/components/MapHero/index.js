export { default } from './MapHero';
