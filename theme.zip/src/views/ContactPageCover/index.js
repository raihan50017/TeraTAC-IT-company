export { default } from './ContactPageCover';
