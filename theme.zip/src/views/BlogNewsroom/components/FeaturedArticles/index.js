export { default } from './FeaturedArticles';
