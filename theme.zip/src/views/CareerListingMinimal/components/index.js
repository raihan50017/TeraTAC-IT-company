export { default as About } from './About';
export { default as Features } from './Features';
export { default as Hero } from './Hero';
export { default as Jobs } from './Jobs';
export { default as Newsletter } from './Newsletter';
