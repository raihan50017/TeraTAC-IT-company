export { default } from './CareerListingMinimal';
