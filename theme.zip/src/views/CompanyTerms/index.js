export { default } from './CompanyTerms';
